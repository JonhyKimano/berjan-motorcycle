
const items = {
  parts: [
    { name: 'Масляный фильтр', price: 500 },
    { name: 'Тормозные колодки', price: 1200 },
    { name: 'Свечи зажигания', price: 800 }
  ],
  other: [
    { name: 'Автохимия', price: 300 },
    { name: 'Аксессуары', price: 900 },
    { name: 'Инструменты', price: 1500 }
  ]
};

let cart = [];
let currentSection = 'parts';

function renderItems(section) {
  const list = document.getElementById(section + '-list');
  list.innerHTML = '';
  items[section].forEach((item, index) => {
    const div = document.createElement('div');
    div.className = 'item';
    div.innerHTML = `<span>${item.name} - ${item.price}₽</span> <button onclick="addToCart('${section}', ${index})">Добавить</button>`;
    list.appendChild(div);
  });
}

function showSection(id) {
  currentSection = id;
  document.querySelectorAll('.section').forEach(section => {
    section.classList.remove('active');
  });
  document.getElementById(id).classList.add('active');
  renderItems(id);
}

function addToCart(section, index) {
  const item = items[section][index];
  cart.push(item);
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart');
  cartList.innerHTML = '';
  cart.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} - ${item.price}₽`;
    cartList.appendChild(li);
  });
}

function sortItems(order) {
  items[currentSection].sort((a, b) => {
    return order === 'cheap' ? a.price - b.price : b.price - a.price;
  });
  renderItems(currentSection);
}

renderItems('parts');
renderItems('other');
